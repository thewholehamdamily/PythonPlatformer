# PythonPlatformer
Our goal was to make a platformer using python for our own personal gain as we are all interested in games.

Use the arrow keys to move and jump. You can also jump with x. Z is shoot.
Defeat all the enemies to win.

Libraries: Pygame

Donovan worked on the boss and enemy design
Redden created the level design kit, collisions, and enemy AI
Cameron built the main game loop, hud, and player